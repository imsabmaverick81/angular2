import { Injectable } from '@angular/core';
import {Country} from './country';
import {State} from './state';
import {City} from './city';
@Injectable()
export class CountryStateService {
  getCountries() {
    return [
      new Country(1,'India'),
      new Country(2,'USA'),
      new Country(3,'Russia')
    ];
  }
  getState() {
    return [
      new State(1,1,'Mumbai'),
      new State(2,1,'Kolkata'),
      new State(3,1,'Delhi'),
      new State(4,1,'Chennai'),
      new State(1,2,'New Jersey'),
      new State(2,2,'New York'),
      new State(3,2,'Michigan'),
      new State(4,2,'Detroit')
    ];
  }
  getCity() {
    return [
      new City(1,1,'Pune'),
      new City(2,1,'Nagpur'),
      new City(3,1,'Amravati'),
      new City(4,1,'Sholapur'),
      new City(5,1,'Kolhapur'),
      new City(1,2,'Asansol'),
      new City(2,2,'Durgapur'),
      new City(3,2,'Sealdah'),
      new City(4,2,'Mednipore'),
    ];
  }
}