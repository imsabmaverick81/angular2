export class Country {
  constructor(public countryId: number,
              public countryName: string){}
}