import { Component } from '@angular/core';
import { CountryStateService } from './countryState.service';

import { Country } from './country';
import { State } from './state';
import { City } from './city';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Cascading dropdowns example';
  selectedCountry: Country = new Country(0, 'India');
  selectedState: State = new State(0, 0, 'Mumbai');
  countries: Country[];
  states: State[];
  cities: City[];
  constructor(private _countryState: CountryStateService){
    this.countries = this._countryState.getCountries();
  }

  onselectCountry(countryId) {
    console.log("countryId: " + countryId);
    this.states = this._countryState.getState()
                      .filter(item => item.countryId == countryId);
  }

  onselectState(countryId, stateId) {
    console.log("StateId: " + stateId);
    this.cities = this._countryState.getCity()
                      .filter((item) => item.stateId == stateId);
    this.cities.forEach((item) => {
      console.log(item.cityId + "-" + item.cityName);
    })
  }
}
