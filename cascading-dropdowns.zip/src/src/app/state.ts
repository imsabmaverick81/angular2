export class State {
  constructor(public stateId: number,
  public countryId: number,
  public stateName: string) {}
}