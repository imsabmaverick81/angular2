export class City {
  constructor(public cityId: number,
              public stateId: number,
              public cityName: string){}
}